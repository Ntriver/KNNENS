clc;clear
addpath('Scripts\KNNENS src codes')
    rseed = 2021;
    NUM_BAGS = 20;
    NUM_BOOTSTRAPS = 20;
    knnens_threshold = 0.9;
    BUFFER_SIZE = 300;
    K = 5;
    SUB_SIZE = 1;
    
datanames = {'synthetic_data'};
for d = 1:numel(datanames)
    dataset_name = datanames{d};
    load(['Datasets\',dataset_name,'.mat'],'te_X','te_y','tr_X','tr_y');
    
    params = struct();
    params.threshold = knnens_threshold;
    params.num_bags =NUM_BAGS;
    params.num_bootstraps = NUM_BOOTSTRAPS;
    params.buffer_size = BUFFER_SIZE;
    params.rseed = rseed;
    params.k = K;
    params.sub_size = SUB_SIZE;
    
    
    tstart=tic;
    model = fit_knnens(tr_X, tr_y, params);
    pred = predict_knnens(te_X, model, params);
    
    elapse_time = toc(tstart);
    acc = sum(pred==te_y)/size(te_y,1);
    
    fprintf(['RUN TIME: ', num2str(elapse_time), '\n'])
    disp(['KNNENS ACC:',num2str(acc)])
    disp('-----------------------------------')


end








