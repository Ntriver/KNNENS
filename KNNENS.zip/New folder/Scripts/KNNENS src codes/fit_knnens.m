function model = fit_knnens(data, label, params)
    tknn = tic;

    n_features = size(data,2);
    
    rng(params.rseed,'twister');
    model = struct();
    model.classes = unique(label);
    model.class_model = {};
    n_classes = numel(model.classes);
    n_bootstraps = params.num_bootstraps;
    for j = 1:params.num_bags
        tmp_label = zeros(n_classes*n_bootstraps,1);
        tmp_radius = zeros(n_classes*n_bootstraps,1);
        tmp_data = zeros(n_classes*n_bootstraps,ceil(params.sub_size*n_features));
        
        subspace_idx = randperm(n_features,ceil(params.sub_size*n_features));
        for i = 1:numel(model.classes)
            ci = model.classes(i);
            subdata = data(label==ci,:);
            shuffle_idx = randperm(size(subdata,1),n_bootstraps);
            bag_data = subdata(shuffle_idx,subspace_idx);
            [~,nn_dist] = knnsearch(bag_data,bag_data,'k',params.k+1);
            radius = mean(nn_dist(:,2:end),2);
            tmp_label(n_bootstraps*(i-1)+1:n_bootstraps*i,:) = ones(n_bootstraps,1)*ci;
            tmp_data(n_bootstraps*(i-1)+1:n_bootstraps*i,:) = bag_data;
            tmp_radius(n_bootstraps*(i-1)+1:n_bootstraps*i,:) = radius;
        end
        nn_model = struct();
        nn_model.radius = tmp_radius;
        nn_model.label = tmp_label;
        nn_model.data = tmp_data;
        nn_model.subspace_idx = subspace_idx;
        model.class_model{j} = nn_model;
    end
    model.buffer = [];
    fprintf('knnens training time: %f\n',toc(tknn))
        
        
        
    