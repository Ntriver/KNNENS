function [final_pred,model] = calculate_score_knnens(data, model,threshold, buffer_size, n_bootstraps)
% tscore = tic;
    
    preds = zeros(size(data,1),numel(model.class_model));
    for i = 1:numel(model.class_model)
%         tscore = tic;
        class_model = model.class_model{i};
        tmp_label = class_model.label;
        radius = class_model.radius;    
        save_data = class_model.data;
        subspace_idx = class_model.subspace_idx;
        n_save_data = size(save_data,1);
        
        
        if size(save_data,1)>=10
%             testtic = tic;
            nn_dist = pdist2(data(:,subspace_idx),save_data);
%             toc(testtic)
        else
%             testtic = tic;
            nn_dist = zeros(1,n_save_data);
            for ii = 1:n_save_data
                nn_dist(ii) = Dist(data(:,subspace_idx),save_data(ii,:));
            end
%             toc(testtic);
        end
        %%% find k-nearest neighbor
        [~,min_idx] = min(nn_dist,[],2);
        tmp_pred = tmp_label(min_idx);

        
        %%% update pred if it is from new class
        
        score = nn_dist ./ repmat(radius',size(nn_dist,1),1);
        n_s = sum(score<threshold,2);
        
        preds(:,i) = tmp_pred;
        preds(n_s<=0,i) = 999;
    end
    final_pred = mode(preds,2);
    
    %% update if buffer is full
    if final_pred==999
        model.buffer = [model.buffer;data];
        buffer = model.buffer;
        if size(buffer,1)==buffer_size
%             n_classes = numel(model.classes);
            update_tic = tic;
            model = add_class_data(buffer,999,model,n_bootstraps);
%             model.classes = [model.classes;n_classes+1];
            model.buffer = [];
            fprintf('knnens update used time: %f\n', toc(update_tic))
        end
    end

    

                
        