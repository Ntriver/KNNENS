function new_model = add_class_data(data, label, model, n_bootstraps)
        class_model = model.class_model;
        
        if sum(ismember(model.classes,label))>0
            % class exists in current model
            % remove exists data and replace with new data
            for i = 1:numel(class_model)
                ci = label;
                crt_model = class_model{i};
                crt_model_label = crt_model.label;
                label_idx = crt_model_label==ci;
                crt_model.radius(label_idx,:) = [];
                crt_model.label(label_idx,:) = [];
                crt_model.data(label_idx,:) = [];
                model.class_model{i} = crt_model;
            end
            classes = model.classes;
            model.classes(classes==label) = [];
        end
        
        class_model = model.class_model;
        for i = 1:numel(class_model)
            ci = label;
            crt_model = class_model{i};
            subspace_idx = crt_model.subspace_idx;
            subdata = data;
            shuffle_idx = randperm(size(subdata,1),n_bootstraps);
            bag_data = subdata(shuffle_idx,subspace_idx);
            [~,nn_dist] = knnsearch(bag_data,bag_data,'k',5+1);
            radius = mean(nn_dist(:,2:end),2);
            tmp_label = ones(n_bootstraps,1)*ci;
            crt_model.radius = [crt_model.radius;radius];
            crt_model.label = [crt_model.label;tmp_label];
            crt_model.data = [crt_model.data;bag_data];
            model.class_model{i} = crt_model;
        end
        model.classes = [model.classes;999];
%         fprintf('crt classes: %f\n',model.classes)
        new_model = model;
            
end