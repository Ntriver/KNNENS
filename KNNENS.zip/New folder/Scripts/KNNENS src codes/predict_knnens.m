function [pred,model] = predict_knnens(data, model, params)
    tknn = tic;
    n_instances = size(data,1);
    pred = zeros(n_instances,1);
    threshold = params.threshold;
    buffer_size = params.buffer_size;
    n_bootstraps = params.num_bootstraps;

    
    
    for i = 1:size(data,1)
        if mod(i,1000)==0
            disp(num2str(i))
            fprintf('knnens test time: %f\n',toc(tknn))
        end
        [pred(i,1),model] = calculate_score_knnens(data(i,:),model,threshold,buffer_size,n_bootstraps);
    end
    fprintf('knnens test time: %f\n',toc(tknn))
    
end
            